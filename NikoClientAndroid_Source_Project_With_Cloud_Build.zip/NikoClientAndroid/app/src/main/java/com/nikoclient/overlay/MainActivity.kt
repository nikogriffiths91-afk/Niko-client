package com.nikoclient.overlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : Activity() {
    private val bg = Color.rgb(16, 11, 24)
    private val purple = Color.rgb(157, 76, 255)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "NikoClient"
            textSize = 30f
            setTextColor(Color.WHITE)
            typeface = Typeface.create("sans-serif-black", Typeface.BOLD)
        }
        val sub = TextView(this).apply {
            text = "BEDROCK COMPANION  •  ANDROID"
            textSize = 12f
            setTextColor(Color.rgb(190, 151, 255))
            setPadding(0, 4, 0, 24)
        }
        root.addView(title)
        root.addView(sub)
        root.addView(cardText("Floating menu", "Show a movable NikoClient button over other apps."))
        root.addView(actionButton("GRANT OVERLAY PERMISSION") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        root.addView(actionButton("START FLOATING MENU") {
            if (Settings.canDrawOverlays(this)) {
                startService(Intent(this, OverlayService::class.java))
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })
        root.addView(actionButton("OPEN MINECRAFT") {
            val launch = packageManager.getLaunchIntentForPackage("com.mojang.minecraftpe")
            if (launch != null) startActivity(launch) else cardDialog("Minecraft not found", "Install Minecraft Bedrock from the official app store, then try again.")
        })
        root.addView(actionButton("IMPORT NIKOCLIENT .MCADDON") {
            val pick = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
                putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/octet-stream", "application/zip", "*/*"))
            }
            startActivityForResult(pick, 42)
        })
        root.addView(TextView(this).apply {
            text = "LIMITATION\nThe floating menu is an Android overlay, not code injected into Minecraft. Its demo switches do not control in-game modules. Importing the add-on opens it with Android's available app handler."
            textSize = 13f
            setTextColor(Color.rgb(197, 187, 210))
            setPadding(0, 22, 0, 0)
        })
        setContentView(root)
    }

    private fun cardText(head: String, body: String) = TextView(this).apply {
        text = "$head\n$body"
        textSize = 15f
        setTextColor(Color.WHITE)
        setPadding(18, 18, 18, 18)
        background = GradientDrawable().apply { setColor(Color.rgb(35, 25, 48)); cornerRadius = 22f; setStroke(1, Color.rgb(90, 57, 126)) }
    }

    private fun actionButton(label: String, action: () -> Unit) = Button(this).apply {
        text = label
        textSize = 13f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply { setColor(purple); cornerRadius = 18f }
        isAllCaps = false
        setOnClickListener { action() }
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.topMargin = 12
        layoutParams = lp
    }

    private fun cardDialog(head: String, body: String) {
        android.app.AlertDialog.Builder(this).setTitle(head).setMessage(body).setPositiveButton("OK", null).show()
    }

    @Deprecated("Deprecated in Android API, retained for broad device compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 42 && resultCode == RESULT_OK) {
            val uri = data?.data ?: return
            val open = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/octet-stream")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            try { startActivity(Intent.createChooser(open, "Open NikoClient add-on")) }
            catch (_: Exception) { cardDialog("Can't open file", "Your device did not provide an app to import this file. Open the .mcaddon from your Files app and choose Minecraft.") }
        }
    }
}
