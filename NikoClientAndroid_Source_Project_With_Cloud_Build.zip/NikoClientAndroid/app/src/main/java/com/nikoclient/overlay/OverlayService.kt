package com.nikoclient.overlay

import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var bubble: TextView? = null
    private var panel: LinearLayout? = null
    private var panelParams: WindowManager.LayoutParams? = null
    private val purple = Color.rgb(157, 76, 255)
    private val dark = Color.rgb(23, 16, 33)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (bubble != null) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        bubble = TextView(this).apply {
            text = "N"
            textSize = 22f
            gravity = Gravity.CENTER
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { setColor(purple); shape = GradientDrawable.OVAL; setStroke(2, Color.rgb(220, 187, 255)) }
            setOnClickListener { togglePanel() }
        }
        val bubbleParams = WindowManager.LayoutParams(56, 56, type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 24; y = 220
        }
        bubble?.setOnTouchListener(object : View.OnTouchListener {
            var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
            override fun onTouch(v: View, e: MotionEvent): Boolean {
                when (e.action) {
                    MotionEvent.ACTION_DOWN -> { sx=e.rawX; sy=e.rawY; ox=bubbleParams.x; oy=bubbleParams.y; moved=false; return true }
                    MotionEvent.ACTION_MOVE -> {
                        val dx=(e.rawX-sx).toInt(); val dy=(e.rawY-sy).toInt()
                        if (kotlin.math.abs(dx)>5 || kotlin.math.abs(dy)>5) moved=true
                        bubbleParams.x=ox+dx; bubbleParams.y=oy+dy
                        wm.updateViewLayout(bubble, bubbleParams); return true
                    }
                    MotionEvent.ACTION_UP -> { if (!moved) togglePanel(); return true }
                }
                return false
            }
        })
        wm.addView(bubble, bubbleParams)
        return START_NOT_STICKY
    }

    private fun togglePanel() {
        if (panel != null) { removePanel(); return }
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 16, 18, 16)
            background = GradientDrawable().apply { setColor(dark); cornerRadius = 28f; setStroke(2, purple) }
        }
        p.addView(label("NikoClient", 21f, Color.WHITE))
        p.addView(label("BEDROCK OVERLAY • DEMO", 10f, Color.rgb(195, 157, 255)))
        p.addView(moduleRow("Coordinates HUD"))
        p.addView(moduleRow("Welcome message"))
        p.addView(moduleRow("Module settings"))
        p.addView(label("These are visual demo toggles; they don't alter Minecraft.", 11f, Color.LTGRAY))
        p.addView(label("✕  CLOSE MENU", 13f, Color.WHITE).apply {
            setPadding(10, 16, 10, 8)
            setOnClickListener { removePanel() }
        })
        val params = WindowManager.LayoutParams(300, WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE, PixelFormat.TRANSLUCENT).apply {
            gravity = Gravity.CENTER
        }
        panel = p; panelParams = params
        wm.addView(p, params)
    }

    private fun label(textValue: String, size: Float, color: Int) = TextView(this).apply {
        text = textValue; textSize = size; setTextColor(color); setPadding(6, 5, 6, 5)
    }

    private fun moduleRow(name: String): TextView = TextView(this).apply {
        text = "◉   $name       OFF"
        textSize = 14f; setTextColor(Color.WHITE); setPadding(12, 12, 12, 12)
        background = GradientDrawable().apply { setColor(Color.rgb(48, 33, 65)); cornerRadius = 14f }
        val lp = LinearLayout.LayoutParams(-1, -2); lp.topMargin = 8; layoutParams = lp
        var on = false
        setOnClickListener { on = !on; text = "◉   $name       ${if (on) "ON" else "OFF"}"; alpha = if (on) 1f else 0.75f }
    }

    private fun removePanel() {
        panel?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        panel = null; panelParams = null
    }

    override fun onDestroy() {
        removePanel()
        bubble?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        bubble = null
        super.onDestroy()
    }
}
