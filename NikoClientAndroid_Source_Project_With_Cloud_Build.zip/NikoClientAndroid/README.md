# NikoClient Android companion (source project)

This is an Android Studio project for a purple floating overlay menu and Minecraft Bedrock launcher/import helper.

## What works in this prototype
- Android app home screen
- Requests the user's explicit Android overlay permission
- Floating draggable `N` button and purple panel over other apps
- Visual demo toggles
- Launches Minecraft Bedrock if installed
- Lets you pick a `.mcaddon` file and asks Android to open it with an available handler

## Important limitations
- This app does **not** inject code into Minecraft.
- The overlay switches are UI demos; they do not toggle Bedrock add-on modules.
- Add-on importing depends on Android's file/app association. If the chooser cannot import it, open the `.mcaddon` from Files and choose Minecraft.
- Android may restrict overlays over particular screens, and the user must grant "Display over other apps" permission.

## Build an APK
1. Open this folder in Android Studio (recent version).
2. Allow Gradle sync and install Android SDK Platform 35 if prompted.
3. Choose **Build > Build APK(s)**.
4. The debug APK will be under `app/build/outputs/apk/debug/`.

This environment did not have Android SDK/Gradle installed, so no APK was compiled here. This ZIP is the Android Studio source project, not an APK.

## Build from a phone with a cloud runner
A GitHub Actions workflow is included at `.github/workflows/build-apk.yml`. Once the project files are committed to a GitHub repository, open the repository's **Actions** tab, choose **Build NikoClient APK**, and tap **Run workflow**. When it finishes, open the successful run and download the `NikoClient-debug-apk` artifact. Extract the downloaded artifact ZIP to get the APK. This cloud workflow has not been run from this environment, so build success is not yet verified.
